display-year
================

See the [component page](http://saan1984.github.io/display-year) for more information.

## Getting Started

We've put together a [guide for display-year](http://www.polymer-project.org/docs/start/reusableelements.html) to help get you rolling.
