describe("say-hello", function() {
    it("should XXX", function() {

    });
});