describe("ts-clock", function() {
    it("should XXX", function() {

    });
});